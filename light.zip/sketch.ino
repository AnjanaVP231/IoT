#include <WiFi.h> 
#include <PubSubClient.h> 
/* WiFi */ 
const char* ssid = "Wokwi-GUEST"; 
const char* password = ""; 
/* Adafruit IO */ 
#define MQTT_SERVER "io.adafruit.com" 
#define MQTT_PORT 1883 
#define MQTT_USER "AnjanaVP" 
#define MQTT_KEY  "aio_IsTM433Jg0CT8m0aUwxWMlBXP5Te" 
/* GPIOs */ 
int leds[4] = {16, 17, 18, 19}; 
bool ledState[4] = {false, false, false, false}; 
/* Feeds */ 
const char* feeds[4] = { 
"AnjanaVP/feeds/r1", 
"AnjanaVP/feeds/r2", 
"AnjanaVP/feeds/r3", 
"AnjanaVP/feeds/r4" 
}; 
WiFiClient espClient; 
PubSubClient client(espClient); 

void callback(char* topic, byte* payload, unsigned int length) {

  String msg = "";
  for (int i = 0; i < length; i++) {
    msg += (char)payload[i];
  }

  if (msg != "TOGGLE") return;

  for (int i = 0; i < 4; i++) {
    if (String(topic) == feeds[i]) {
      ledState[i] = !ledState[i];
      digitalWrite(leds[i], ledState[i] ? HIGH : LOW);
    }
  }
}

 
void connectMQTT() { 
  while (!client.connected()) { 
    if (client.connect("ESP32_LED_NODE", MQTT_USER, MQTT_KEY)) { 
      for (int i = 0; i < 4; i++) { 
        client.subscribe(feeds[i]); 
      } 
    } else { 
      delay(2000); 
    } 
  } 
} 
 
void setup() { 
  for (int i = 0; i < 4; i++) { 
    pinMode(leds[i], OUTPUT); 
    digitalWrite(leds[i], LOW); 
  } 
 
  WiFi.begin(ssid, password); 
  while (WiFi.status() != WL_CONNECTED) delay(500); 
 
  client.setServer(MQTT_SERVER, MQTT_PORT); 
  client.setCallback(callback); 
} 
 
void loop() { 
if (!client.connected()) connectMQTT(); 
client.loop(); 
}