#include <WiFi.h> 
#include <PubSubClient.h> 
/* WiFi */ 
const char* ssid = "Wokwi-GUEST"; 
const char* password = ""; 
/* Adafruit IO */ 
#define MQTT_SERVER "io.adafruit.com" 
#define MQTT_PORT 1883 
#define MQTT_USER "AnjanaVP" 
#define MQTT_KEY  "aio_IsTM433Jg0CT8m0aUwxWMlBXP5Te" 
/* GPIOs */ 
int buttons[4] = {16, 17, 18, 19}; 
int lastState[4] = {HIGH, HIGH, HIGH, HIGH}; 
/* Feeds */ 
const char* feeds[4] = { 
"AnjanaVP/feeds/r1", 
"AnjanaVP/feeds/r2", 
"AnjanaVP/feeds/r3", 
"AnjanaVP/feeds/r4" 
}; 
WiFiClient espClient; 
PubSubClient client(espClient); 
void connectMQTT() { 
while (!client.connected()) { 
client.connect("ESP32_BUTTON_NODE", MQTT_USER, MQTT_KEY); 
delay(2000); 
} 
} 
void setup() { 
for (int i = 0; i < 4; i++) { 
pinMode(buttons[i], INPUT_PULLUP); 
  } 
 
  WiFi.begin(ssid, password); 
  while (WiFi.status() != WL_CONNECTED) delay(500); 
 
  client.setServer(MQTT_SERVER, MQTT_PORT); 
} 
 
void loop() { 
  if (!client.connected()) connectMQTT(); 
  client.loop(); 
 
  for (int i = 0; i < 4; i++) { 
    int current = digitalRead(buttons[i]); 
 
    /* Detect button press (HIGH → LOW) */ 
    if (lastState[i] == HIGH && current == LOW) { 
      client.publish(feeds[i], "TOGGLE"); 
      delay(200); // debounce 
    } 
 
    lastState[i] = current; 
  } 
} 
